package Model;

import java.util.*;
import java.sql.*;
import com.*;
import java.io.*;

public class Booking extends Connect
{
    /////Function for connect to the MySQL Server Database////////////
	public Booking()
    {
		Connect.connect_mysql();
    }
	//////////Save User Details /////
	public int saveBooking(HashMap bookingData)
	{
		String SQL = "INSERT INTO `booking` (`booking_name`, `booking_email`, `booking_mobile`, `booking_requirements`, `booking_customer_id`, `booking_date`, `booking_center_id`) VALUES (?, ?, ?, ?, ?, ?, ?);";
		int record=0, last_inserted_id=0; 
		String error = "";
		
		try
		{
			pstmt = connection.prepareStatement(SQL);
			pstmt.setString(1,(String) bookingData.get("booking_name"));
			pstmt.setString(2,(String) bookingData.get("booking_email"));
			pstmt.setString(3,(String) bookingData.get("booking_mobile"));
			pstmt.setString(4,(String) bookingData.get("booking_requirements"));
			pstmt.setString(5,(String) bookingData.get("booking_customer_id"));
			pstmt.setString(6,(String) bookingData.get("booking_date"));
			pstmt.setString(7,(String) bookingData.get("booking_center_id"));
			
			
			record = pstmt.executeUpdate();
			rs = pstmt.getGeneratedKeys();
			if(rs.next())
			{
				last_inserted_id = rs.getInt(1);
			}
			pstmt.close();
			connection.close();
		}
		catch(Exception e)
		{
			StringWriter writer = new StringWriter();
			PrintWriter printWriter = new PrintWriter( writer );
			e.printStackTrace( printWriter );
			printWriter.flush();
			String stackTrace = writer.toString();
			error+="Error : "+stackTrace;
			System.out.println(" Error : "+ e.toString());
		}
		return last_inserted_id;
	}
	//////////////////Function for getting Users Details//////////	
    public HashMap getBookingDetails(String booking_id)
	{
        HashMap results = new HashMap();
        int count=0;
		try
		{
            String SQL =  "SELECT * FROM `location`,`booking`, `customer`, `center` WHERE booking_center_id = center_id AND booking_customer_id = customer_id AND location_id = center_location_id AND booking_id = "+booking_id ;
            statement = connection.createStatement();
            rs = statement.executeQuery(SQL);
            while(rs.next())
			{
				results.put("booking_id",rs.getString("booking_id"));
				results.put("booking_name",rs.getString("booking_name"));
				results.put("booking_email",rs.getString("booking_email"));
				results.put("booking_requirements",rs.getString("booking_requirements"));
				results.put("booking_mobile",rs.getString("booking_mobile"));
				results.put("booking_id",rs.getString("booking_id"));
				results.put("booking_name",rs.getString("booking_name"));
				results.put("booking_email",rs.getString("booking_email"));
				results.put("booking_requirements",rs.getString("booking_requirements"));
				results.put("booking_mobile",rs.getString("booking_mobile"));
				results.put("booking_date",rs.getString("booking_date"));
				results.put("customer_name",rs.getString("customer_name"));
				results.put("customer_mobile",rs.getString("customer_mobile"));
				results.put("customer_email",rs.getString("customer_email"));
				results.put("customer_password",rs.getString("customer_password"));
				results.put("customer_address",rs.getString("customer_address"));
				results.put("customer_city",rs.getString("customer_city"));
				results.put("customer_state",Integer.parseInt(rs.getString("customer_state")));
				results.put("customer_pincode",rs.getString("customer_pincode"));	
				results.put("customer_id",rs.getString("customer_id"));	
				results.put("center_name",rs.getString("center_name"));
				results.put("center_location_id",Integer.parseInt(rs.getString("center_location_id")));
				results.put("center_company_id",Integer.parseInt(rs.getString("center_company_id")));
				results.put("center_description",rs.getString("center_description"));
				results.put("center_contact",rs.getString("center_contact"));
				results.put("location_name",rs.getString("location_name"));
				results.put("center_id",rs.getString("center_id"));
				results.put("center_image",rs.getString("center_image"));
				results.put("center_email",rs.getString("center_email"));
				count++;
            }
			if(count==0)
			{
				results.put("booking_id","");
				results.put("booking_name","");
				results.put("booking_email","");
				results.put("booking_requirements","");
				results.put("booking_mobile","");
			}
         }
		 catch(Exception e)
		 {
            System.out.println("Error is: "+ e);
       	 }
        return results;
    }
    /// Update the Booking ////
	public String updateBooking(HashMap bookingData)
	{
		String SQL = "UPDATE `booking` SET `booking_name` = ?, `booking_email` = ?, `booking_mobile` = ?, `booking_requirements` = ?, `booking_customer_id` = ?, `booking_date` = ?, booking_center_id = ? WHERE `booking_id` = ?;";
		String error = "";
		
		int record=0;	
		
		try
		{
			pstmt = connection.prepareStatement(SQL);
			
			pstmt.setString(1,(String) bookingData.get("booking_name"));
			pstmt.setString(2,(String) bookingData.get("booking_email"));
			pstmt.setString(3,(String) bookingData.get("booking_mobile"));
			pstmt.setString(4,(String) bookingData.get("booking_requirements"));
			pstmt.setString(5,(String) bookingData.get("booking_customer_id"));
			pstmt.setString(6,(String) bookingData.get("booking_date"));
			pstmt.setString(7,(String) bookingData.get("booking_center_id"));
			pstmt.setString(8,(String) bookingData.get("booking_id"));
			
			record = pstmt.executeUpdate();
			pstmt.close();
			connection.close();
		}
		catch(Exception e)
		{
			StringWriter writer = new StringWriter();
			PrintWriter printWriter = new PrintWriter( writer );
			e.printStackTrace( printWriter );
			printWriter.flush();
			String stackTrace = writer.toString();
			error+="Error : "+stackTrace;
			System.out.println(" Error : "+ e.toString());
		}
		return error;
	}
	
	////////////////Function for getting all the Airport Details////////////////////  
    public ArrayList getAllBooking(int customerID)
	{
		String SQL = "SELECT * FROM `booking`, `customer`, `center` WHERE booking_center_id = center_id AND booking_customer_id = customer_id";
		if(customerID != 0)
			SQL = "SELECT * FROM `booking`, `customer`, `center` WHERE booking_center_id = center_id AND booking_customer_id = customer_id AND customer_id = "+customerID;
		
		int count=0;
        ArrayList resultArray = new ArrayList();
        try
		{			
			statement = connection.createStatement();
            rs = statement.executeQuery(SQL);
            while(rs.next())
			{		
				HashMap results = new HashMap();
				results.put("booking_id",rs.getString("booking_id"));
				results.put("booking_name",rs.getString("booking_name"));
				results.put("booking_email",rs.getString("booking_email"));
				results.put("booking_requirements",rs.getString("booking_requirements"));
				results.put("booking_mobile",rs.getString("booking_mobile"));
				results.put("booking_date",rs.getString("booking_date"));
				results.put("customer_name",rs.getString("customer_name"));
				results.put("customer_mobile",rs.getString("customer_mobile"));
				results.put("customer_email",rs.getString("customer_email"));
				results.put("customer_password",rs.getString("customer_password"));
				results.put("customer_address",rs.getString("customer_address"));
				results.put("customer_city",rs.getString("customer_city"));
				results.put("customer_state",Integer.parseInt(rs.getString("customer_state")));
				results.put("customer_pincode",rs.getString("customer_pincode"));	
				results.put("customer_id",rs.getString("customer_id"));	
				results.put("center_name",rs.getString("center_name"));
				results.put("center_location_id",Integer.parseInt(rs.getString("center_location_id")));
				results.put("center_company_id",Integer.parseInt(rs.getString("center_company_id")));
				results.put("center_description",rs.getString("center_description"));
				results.put("center_contact",rs.getString("center_contact"));
				results.put("center_id",rs.getString("center_id"));
				results.put("center_image",rs.getString("center_image"));
				results.put("center_email",rs.getString("center_email"));
				
				count++;
                resultArray.add(results);
            }
         }
		catch(Exception e)
		{
            System.out.println("Error is: "+ e);
        }
        return resultArray;
    }
}
