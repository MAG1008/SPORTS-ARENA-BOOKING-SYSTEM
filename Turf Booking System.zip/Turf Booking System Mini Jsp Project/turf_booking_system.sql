-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 02, 2021 at 02:06 PM
-- Server version: 5.7.28-0ubuntu0.19.04.2
-- PHP Version: 7.2.24-0ubuntu0.19.04.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `turf_booking_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `booking_id` int(11) NOT NULL,
  `booking_name` varchar(255) NOT NULL,
  `booking_email` varchar(255) NOT NULL,
  `booking_mobile` varchar(255) NOT NULL,
  `booking_requirements` text NOT NULL,
  `booking_customer_id` varchar(255) NOT NULL,
  `booking_date` varchar(255) NOT NULL,
  `booking_center_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`booking_id`, `booking_name`, `booking_email`, `booking_mobile`, `booking_requirements`, `booking_customer_id`, `booking_date`, `booking_center_id`) VALUES
(1, 'Kaushal Kishore', 'kaushal@gmail.com', '9876543212', 'Booking for marriage functions ', '1', '18 Feb, 2019 8:06:53 PM', '1'),
(2, 'Atul Kumar', 'atul@gmail.com', '9876543212', 'Booking for reception functions ', '2', '18 Feb, 2019 11:22:57 PM', '2'),
(3, 'Aman Kumar', 'aman@gmail.com', '7867564543', 'Booking for birthday functions ', '3', '18 Feb, 2019 11:33:04 PM', '3'),
(4, 'Pawan Kumar', 'pawan@gmail.com', '98778967876', 'Booking for marriage functions ', '1', '18 Feb, 2019 11:34:23 PM', '1'),
(5, 'Amit Singh', 'amit@gmail.com', '7891234322', 'Booking for kitty party functions ', '2', '21 Feb, 2019 8:37:51 PM', '8'),
(6, 'Sumit Singh', 'sumit@gmail.com', '7845876545', 'Booking for conference functions ', '1', '21 Feb, 2019 10:06:43 PM', '6'),
(7, 'Pawan Kumar', 'pawan@gmai.com', '983547348957', 'Booking for seminar functions ', '1', '22 Feb, 2019 12:21:04 AM', '1'),
(8, 'Kaushal Kishore', 'kaushal@gmail.com', '9876543212', 'Marriage Functions', '1', '5 Sep, 2019 3:32:29 PM', '1');

-- --------------------------------------------------------

--
-- Table structure for table `center`
--

CREATE TABLE `center` (
  `center_id` int(11) NOT NULL,
  `center_name` varchar(255) NOT NULL,
  `center_location_id` varchar(255) NOT NULL,
  `center_company_id` varchar(255) NOT NULL,
  `center_contact` varchar(255) NOT NULL,
  `center_image` varchar(255) NOT NULL,
  `center_description` text NOT NULL,
  `center_email` varchar(255) NOT NULL,
  `center_total_guest` varchar(255) NOT NULL,
  `center_services` text NOT NULL,
  `center_starting_cost` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `center`
--

INSERT INTO `center` (`center_id`, `center_name`, `center_location_id`, `center_company_id`, `center_contact`, `center_image`, `center_description`, `center_email`, `center_total_guest`, `center_services`, `center_starting_cost`) VALUES
(1, 'Firoj Shah', '1', '1', '1204567875', '1.jpeg', 'C 47, Block C, Sector 58, Noida, Uttar Pradesh 201301', 'contact@gmail.com', '1000', 'Seating Facility,Security', '50000/-'),
(2, 'City Pride', '5', '1', '1204534212', '2.jpeg', 'C 47, Block C, Sector 58, Noida, Uttar Pradesh 201301', 'contact@gmail.com', '', 'Seating Facility,Security', ''),
(3, 'Golden Galaxy', '3', '4', '9878675645', '3.jpeg', 'C 47, Block C, Sector 58, Noida, Uttar Pradesh 201301', 'contact@gmail.com', '', 'Seating Facility,Security', ''),
(4, 'New-Four', '5', '4', '9867431234', '4.jpeg', 'C 47, Block C, Sector 58, Noida, Uttar Pradesh 201301', 'contact@gmail.com', '', 'Seating Facility,Security', ''),
(5, 'City Farm', '1', '2', '9123243567', '11.jpeg', 'C 47, Block C, Sector 58, Noida, Uttar Pradesh 201301', 'contact@gmail.com', '', 'Seating Facility,Security', ''),
(6, 'Ramkota', '4', '2', '9867412345', '12.jpeg', 'C 47, Block C, Sector 58, Noida, Uttar Pradesh 201301', 'contact@gmail.com', '', 'Seating Facility,Security', ''),
(7, 'Sanjivani', '6', '2', '9134326787', '13.jpeg', 'C 47, Block C, Sector 58, Noida, Uttar Pradesh 201301', 'contact@gmail.com', '', 'Seating Facility,Security', ''),
(8, 'Soundary', '2', '2', '9123454678', '14.jpeg', 'C 47, Block C, Sector 58, Noida, Uttar Pradesh 201301', 'contact@gmail.com', '', 'Seating Facility,Security', '');

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE `city` (
  `city_id` int(10) UNSIGNED NOT NULL,
  `city_name` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`city_id`, `city_name`) VALUES
(1, 'Mumbai'),
(2, 'Delhi'),
(3, 'Chenai'),
(4, 'Banglore'),
(5, 'Varanasi'),
(6, 'Kolkatta');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `company_id` int(11) NOT NULL,
  `company_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`company_id`, `company_name`) VALUES
(1, 'Blue House'),
(2, 'Naksatra'),
(3, 'Blue'),
(4, 'Community Groups'),
(5, 'Ramoji Groups');

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE `country` (
  `country_id` int(11) NOT NULL,
  `country_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`country_id`, `country_name`) VALUES
(1, 'India'),
(2, 'USA');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_mobile` varchar(255) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  `customer_password` varchar(255) NOT NULL,
  `customer_address` varchar(255) NOT NULL,
  `customer_city` varchar(255) NOT NULL,
  `customer_state` varchar(255) NOT NULL,
  `customer_pincode` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `customer_name`, `customer_mobile`, `customer_email`, `customer_password`, `customer_address`, `customer_city`, `customer_state`, `customer_pincode`) VALUES
(1, 'Amit Kumar', '9876543212', 'amit@gmail.com', 'test', 'Allahabad', 'Mumbai', '4', '201301'),
(2, 'Kaushal Kishore', '9183769868', 'kaushal.rahuljaiswal@gmail.com', 'test', 'A : 42/6 Sector 62', 'Noida', '2', '26101'),
(3, 'Amit', '9876543212', 'rahul@gmail.com', 'test', 'Test', 'Test', '3', 'Test');

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `location_id` int(11) NOT NULL,
  `location_name` varchar(255) NOT NULL,
  `location_description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`location_id`, `location_name`, `location_description`) VALUES
(1, 'Noida Sector 120', 'Noida Sector 120'),
(2, 'Noida Sector 62', 'Noida Sector 62'),
(3, 'Noida Sector 55', 'Noida Sector 55'),
(4, 'Noida Sector 53', 'Noida Sector 53'),
(5, 'Noida Sector 30', 'Noida Sector 30'),
(6, 'Noida Sector 18', 'Noida Sector 18');

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE `state` (
  `state_id` int(11) NOT NULL,
  `state_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`state_id`, `state_name`) VALUES
(1, 'Maharastra'),
(2, 'Gujrat'),
(3, 'Bihar'),
(4, 'Uttar Pradesh'),
(5, 'Delhi'),
(6, 'Haryana');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`booking_id`);

--
-- Indexes for table `center`
--
ALTER TABLE `center`
  ADD PRIMARY KEY (`center_id`);

--
-- Indexes for table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`city_id`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`company_id`);

--
-- Indexes for table `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`country_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`location_id`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
  ADD PRIMARY KEY (`state_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `center`
--
ALTER TABLE `center`
  MODIFY `center_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
  MODIFY `city_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `company_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `country`
--
ALTER TABLE `country`
  MODIFY `country_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `location_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `state`
--
ALTER TABLE `state`
  MODIFY `state_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
